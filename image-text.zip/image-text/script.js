let currentImage;

function openFileInput() {
    document.getElementById('fileElem').click();
}

function handleFileInputChange(event) {
    const files = event.target.files;
    const dropArea = document.getElementById("drop-area");

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.type.startsWith("image/")) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement("img");
                img.src = e.target.result;
                dropArea.innerHTML = "";
                dropArea.appendChild(img);
                currentImage = img;
                img.addEventListener("click", addText);
                img.style.position = "relative"; // Set position relative for proper text positioning
            };
            reader.readAsDataURL(file);
        } else {
            alert("Please select only image files.");
        }
    }
}

function addText(event) {
    const text = prompt("Enter text:");
    if (text !== null && text.trim() !== "") {
        const span = document.createElement("span");
        span.contentEditable = true;
        span.innerText = text;
        span.style.position = "absolute"; // Set position absolute to overlay on the image
        const rect = currentImage.getBoundingClientRect();
        const offsetX = event.clientX - rect.left;
        const offsetY = event.clientY - rect.top;
        span.style.left = `${offsetX}px`; // Position the text at the click coordinates relative to the image
        span.style.top = `${offsetY}px`;
        span.style.cursor = "move"; // Change cursor to indicate draggable element
        span.addEventListener("mousedown", startDragging);
        currentImage.parentNode.appendChild(span);
    }
}

let isDragging = false;

function startDragging(event) {
    isDragging = true;
    const span = event.target;
    const rect = currentImage.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const offsetY = event.clientY - rect.top;
    span.dataset.offsetX = offsetX;
    span.dataset.offsetY = offsetY;
    document.addEventListener("mousemove", dragText);
    document.addEventListener("mouseup", stopDragging);
}

function dragText(event) {
    if (!isDragging) return;
    const span = event.target;
    const rect = currentImage.getBoundingClientRect();
    const offsetX = parseFloat(span.dataset.offsetX);
    const offsetY = parseFloat(span.dataset.offsetY);
    const x = event.clientX - rect.left - offsetX;
    const y = event.clientY - rect.top - offsetY;
    span.style.left = `${x}px`;
    span.style.top = `${y}px`;
}

function stopDragging() {
    isDragging = false;
    document.removeEventListener("mousemove", dragText);
    document.removeEventListener("mouseup", stopDragging);
}
